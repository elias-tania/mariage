<template>
  <header class="header">
    <div class="brand">
      <div class="logo">💍</div>
      <div>
        <div class="title">Notre Mariage</div>
        <div class="subtitle">RSVP & informations</div>
      </div>
    </div>
    <nav class="nav">
      <a href="#inscription">S'inscrire</a>
      <a href="#">Détails</a>
    </nav>
  </header>
</template>

<script>
export default { name: 'Header' }
</script>