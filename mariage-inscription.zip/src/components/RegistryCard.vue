<template>
  <article class="card registry">
    <h3>Infos pratiques</h3>
    <ul>
      <li>📅 Date : 12 juillet 2026</li>
      <li>📍 Lieu : Château de Belle-Vue</li>
      <li>⌚ Horaire : 15:00 cérémonie — soirée</li>
    </ul>
    <p class="muted">Tenue : Chic estival</p>
  </article>
</template>

<script>
export default { name: 'RegistryCard' }
</script>